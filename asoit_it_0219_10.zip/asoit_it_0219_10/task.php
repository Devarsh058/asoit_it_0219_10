<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<?php
// echo "Hello World ";
 
// $a = 5;
// $b = 10;
// $c = $a+$b;
// echo $c;
 
?>
 <form action="" method="post">
        <label for="fname">First name:</label><br>
        <input type="text" id="fname" name="fname"><br><br>
        <label for="lname">Last name:</label><br>
        <input type="text" id="lname" name="lname"><br><br>

        <label for="tech">Select a technology</label><br>

        <input type="radio" id="php" name="fav_language" value="php">
        <label for="php">php</label><br>

        <input type="radio" id="python" name="fav_language" value="python">
        <label for="python">python</label><br>

        <input type="radio" id="nodejs" name="fav_language" value="nodejs">
         <label for="nodejs">nodejs</label><br><br>

         <label for="tech">Select your experience</label><br>
        <input type="checkbox" id="fresher" name="fresher" value="new">
        <label for="fresher">fresher</label><br>
        <input type="checkbox" id="experienced" name="experienced" value="old">
        <label for="experienced">experienced</label><br><br>
      

        <button id="btn">Submit</button>
    </form>
 
</body>
</html>